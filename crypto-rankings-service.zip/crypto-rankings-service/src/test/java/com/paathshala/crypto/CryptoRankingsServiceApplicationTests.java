package com.paathshala.crypto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CryptoRankingsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
